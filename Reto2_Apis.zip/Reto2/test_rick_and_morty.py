import requests
import pytest

URL = "https://rickandmortyapi.com/api/character"

def test_rick_and_morty_api():
    """
    Valida todos los puntos requeridos en el Reto 2 de Covalto:
    - Indicar el tiempo de respuesta de la API
    - Status Code (200)
    - Validación de vivos y muertos
    - Validación de tipos de datos en el response obtenido
    """
    print("\n" + "=" * 75)
    print(" EJECUTANDO PRUEBA DE API: RICK AND MORTY (RETO 2 - COVALTO)")
    print("=" * 75)

    # Usamos Session para optimizar la resolución DNS y conexión
    session = requests.Session()
    response = session.get(URL, timeout=60)

    # -------------------------------------------------------------------------
    # 1. INDICAR EL TIEMPO DE RESPUESTA DE LA API
    # -------------------------------------------------------------------------
    tiempo_ms = response.elapsed.total_seconds() * 1000
    tiempo_seg = response.elapsed.total_seconds()
    print(f"\n[1] TIEMPO DE RESPUESTA DE LA API : {tiempo_ms:.2f} ms ({tiempo_seg:.2f} s)")
    assert tiempo_ms > 0, "El tiempo de respuesta debe ser mayor a 0 ms"

    # -------------------------------------------------------------------------
    # 2. VALIDACIÓN DE STATUS CODE
    # -------------------------------------------------------------------------
    status_code = response.status_code
    print(f"[2] STATUS CODE OBTENIDO          : {status_code} (Esperado: 200)")
    assert status_code == 200, f"Error HTTP: se esperaba 200 y se recibió {status_code}"

    # Obtener el JSON completo
    payload = response.json()

    # Validar estructura principal del JSON
    assert isinstance(payload, dict), "La raíz del JSON debe ser un dict"
    assert "info" in payload and "results" in payload, "Faltan llaves 'info' o 'results'"

    personajes = payload["results"]
    assert isinstance(personajes, list), "'results' debe ser una lista (list)"

    # -------------------------------------------------------------------------
    # 3. VALIDACIÓN DE VIVOS Y MUERTOS + 4. VALIDACIÓN DE TIPOS DE DATOS
    # -------------------------------------------------------------------------
    principales_vivos = []
    vivos = []
    muertos = []
    desconocidos = []

    # IDs de los 5 personajes principales (Rick, Morty, Summer, Beth, Jerry)
    ids_principales = [1, 2, 3, 4, 5]

    print("\n[3 y 4] VALIDACIÓN DE PERSONAJES (VIVOS / MUERTOS) Y TIPOS DE DATOS:")
    print("-" * 75)

    for char in personajes:
        # 4. Validación de tipos de datos del response
        assert isinstance(char["id"], int), f"El campo 'id' debe ser int"
        assert isinstance(char["name"], str), "El campo 'name' debe ser str"
        assert isinstance(char["status"], str), "El campo 'status' debe ser str"
        assert isinstance(char["species"], str), "El campo 'species' debe ser str"
        assert isinstance(char["type"], str), "El campo 'type' debe ser str"
        assert isinstance(char["gender"], str), "El campo 'gender' debe ser str"
        assert isinstance(char["origin"], dict), "El campo 'origin' debe ser dict"
        assert isinstance(char["location"], dict), "El campo 'location' debe ser dict"
        assert isinstance(char["image"], str), "El campo 'image' debe ser str"
        assert isinstance(char["episode"], list), "El campo 'episode' debe ser list"
        assert isinstance(char["url"], str), "El campo 'url' debe ser str"
        assert isinstance(char["created"], str), "El campo 'created' debe ser str"

        # 3. Clasificación y validación de Vivos y Muertos
        estado = char["status"]
        assert estado in ["Alive", "Dead", "unknown"], f"Estado inválido: {estado}"

        if estado == "Alive":
            vivos.append(char["name"])
            if char["id"] in ids_principales:
                principales_vivos.append(char["name"])
        elif estado == "Dead":
            muertos.append(char["name"])
        else:
            desconocidos.append(char["name"])

        print(f" ID: {char['id']:2d} | {char['name']:<26} | Estado: {estado:<8} | Especie: {char['species']:<6} | Tipos: OK")

    print("-" * 75)
    print(f"\n[RESUMEN DE VALIDACIÓN DE VIVOS Y MUERTOS]")
    print(f" -> Personajes Principales y Vivos ({len(principales_vivos)}): {', '.join(principales_vivos)}")
    print(f" -> Total Vivos (Alive)            ({len(vivos)}): {', '.join(vivos)}")
    print(f" -> Total Muertos (Dead)           ({len(muertos)}): {', '.join(muertos)}")
    print(f" -> Total Desconocidos (unknown)   ({len(desconocidos)}): {', '.join(desconocidos)}")

    # Validaciones finales
    assert len(principales_vivos) == 5, "Los 5 personajes principales deben estar vivos"
    assert len(vivos) > 0, "Debe existir al menos un personaje vivo"
    assert len(muertos) > 0, "Debe existir al menos un personaje muerto"

    print("\n[ ÉXITO ] ¡Todas las pruebas y validaciones pasaron correctamente!")
    print("=" * 75 + "\n")