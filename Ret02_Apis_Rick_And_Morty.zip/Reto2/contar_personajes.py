import requests
import pytest

URL = "https://rickandmortyapi.com/api/character"

# Define cuántas páginas (hojas) quieres cubrir (1 página = 20 personajes | Máximo = 42 páginas)
PAGINAS_A_CONSULTAR = 3  


def test_rick_and_morty_api_multipagina():
    print("\n" + "=" * 80)
    print(f" EJECUTANDO PRUEBA DE API: RICK AND MORTY (CUBRIENDO {PAGINAS_A_CONSULTAR} PÁGINAS)")
    print("=" * 80)

    session = requests.Session()

    tiempos_ms = []
    personajes_totales = []

    # -------------------------------------------------------------------------
    # 1 y 2. CONSUMO PAGINADO, TIEMPO DE RESPUESTA Y STATUS CODE POR PÁGINA
    # -------------------------------------------------------------------------
    print("\n[1 y 2] MÉTRICAS DE TIEMPO DE RESPUESTA Y STATUS CODE POR PÁGINA:")
    print("-" * 80)

    for pagina in range(1, PAGINAS_A_CONSULTAR + 1):
        response = session.get(URL, params={"page": pagina}, timeout=60)

        # Medir tiempo de respuesta de cada página
        tiempo_ms = response.elapsed.total_seconds() * 1000
        tiempos_ms.append(tiempo_ms)

        # Validar Status Code 200
        status_code = response.status_code
        print(f" -> Página {pagina:2d} | Status Code: {status_code} | Tiempo de respuesta: {tiempo_ms:7.2f} ms")
        assert status_code == 200, f"Error en página {pagina}: se esperaba 200 y llegó {status_code}"

        # Validar estructura raíz del JSON en cada página
        payload = response.json()
        assert isinstance(payload, dict), "La raíz del JSON debe ser un dict"
        assert "info" in payload and "results" in payload, "Faltan llaves 'info' o 'results'"
        assert isinstance(payload["results"], list), "'results' debe ser una lista (list)"

        personajes_totales.extend(payload["results"])

    tiempo_total_ms = sum(tiempos_ms)
    tiempo_promedio_ms = tiempo_total_ms / len(tiempos_ms)
    print("-" * 80)
    print(f" [MÉTRICA GLOBAL] Tiempo Total: {tiempo_total_ms:.2f} ms | Promedio por página: {tiempo_promedio_ms:.2f} ms")
    print(f" [COBERTURA]      Se descargaron {len(personajes_totales)} personajes de {PAGINAS_A_CONSULTAR} páginas.")

    # -------------------------------------------------------------------------
    # 3. VALIDACIÓN DE VIVOS Y MUERTOS + 4. VALIDACIÓN DE TIPOS DE DATOS
    # -------------------------------------------------------------------------
    principales_vivos = []
    vivos = []
    muertos = []
    desconocidos = []

    # IDs de los 5 personajes principales (Rick, Morty, Summer, Beth, Jerry)
    ids_principales = [1, 2, 3, 4, 5]

    print(f"\n[3 y 4] VALIDACIÓN DE PERSONAJES (VIVOS / MUERTOS) Y TIPOS DE DATOS:")
    print("-" * 80)

    for char in personajes_totales:
        # 4. Validación estricta de tipos de datos en cada personaje
        assert isinstance(char["id"], int), "El campo 'id' debe ser int"
        assert isinstance(char["name"], str), "El campo 'name' debe ser str"
        assert isinstance(char["status"], str), "El campo 'status' debe ser str"
        assert isinstance(char["species"], str), "El campo 'species' debe ser str"
        assert isinstance(char["type"], str), "El campo 'type' debe ser str"
        assert isinstance(char["gender"], str), "El campo 'gender' debe ser str"
        assert isinstance(char["origin"], dict), "El campo 'origin' debe ser dict"
        assert isinstance(char["location"], dict), "El campo 'location' debe ser dict"
        assert isinstance(char["image"], str), "El campo 'image' debe ser str"
        assert isinstance(char["episode"], list), "El campo 'episode' debe ser list"
        assert isinstance(char["url"], str), "El campo 'url' debe ser str"
        assert isinstance(char["created"], str), "El campo 'created' debe ser str"

        # 3. Clasificación y validación de Vivos y Muertos
        estado = char["status"]
        assert estado in ["Alive", "Dead", "unknown"], f"Estado inválido: {estado}"

        if estado == "Alive":
            vivos.append(char["name"])
            if char["id"] in ids_principales:
                principales_vivos.append(char["name"])
        elif estado == "Dead":
            muertos.append(char["name"])
        else:
            desconocidos.append(char["name"])

        print(f" ID: {char['id']:3d} | {char['name']:<28} | Estado: {estado:<8} | Especie: {char['species']:<12} | Tipos: OK")

    print("-" * 80)
    print(f"\n[RESUMEN DE VALIDACIÓN EN LAS {PAGINAS_A_CONSULTAR} PÁGINAS ({len(personajes_totales)} PERSONAJES)]")
    print(f" -> Personajes Principales y Vivos ({len(principales_vivos)}): {', '.join(principales_vivos)}")
    print(f" -> Total Vivos (Alive)            ({len(vivos)})")
    print(f" -> Total Muertos (Dead)           ({len(muertos)})")
    print(f" -> Total Desconocidos (unknown)   ({len(desconocidos)})")

    # Validaciones finales
    assert len(principales_vivos) == 5, "Los 5 personajes principales deben estar vivos"
    assert len(vivos) > 0, "Debe existir al menos un personaje vivo"
    assert len(muertos) > 0, "Debe existir al menos un personaje muerto"
    assert (len(vivos) + len(muertos) + len(desconocidos)) == len(personajes_totales)

    print("\n[ ÉXITO ] ¡Todas las páginas, estados y tipos de datos fueron validados!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    pytest.main(["-v", "-s", __file__])